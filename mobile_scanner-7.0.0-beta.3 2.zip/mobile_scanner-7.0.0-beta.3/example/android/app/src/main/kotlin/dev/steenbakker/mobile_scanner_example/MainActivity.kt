package dev.steenbakker.mobile_scanner_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
